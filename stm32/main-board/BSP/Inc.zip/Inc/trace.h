#include "stm32f4xx_hal.h"

void initTrace();
void Trace(char* str, uint16_t len);
