#include "stm32f4xx_hal.h"

void InitSteering();
void SetSteeringAngle(int8_t angle);
