#include "stm32f4xx_hal.h"

void InitMotor();
void MotorSetTorque(int16_t torqe);
void MotorSetDutyCycle(uint8_t d);
