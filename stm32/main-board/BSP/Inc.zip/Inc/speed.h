#include "stm32f4xx_hal.h"

void InitSpeed();
int16_t GetSpeed();
