#include "stm32f4xx_hal.h"

void InitCommand();
uint8_t GetCommand(char* buf, uint16_t* len);
